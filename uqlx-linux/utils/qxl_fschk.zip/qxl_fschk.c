/*
    filesystem check for QXL/QWA filesystems/partitions
    (c) 1999 Richard Zidlicky

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    NOTE: full GPL not included to save space..
 */



/* a few cross-platform defs */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef signed char w8;
typedef signed short w16;
typedef signed int w32;
typedef unsigned char uw8;
typedef unsigned short uw16;
typedef unsigned int uw32;
typedef char * Ptr;

#ifndef __GNUC__
#define inline
#endif

/* attempt to guess architecture and byteorder */
#undef QM_BIG_ENDIAN

#if defined(sparc) || defined(__sparc)
#define SPARC
#endif

#if defined(__hp9000s800) || defined(hppa)
#define HPPA
#endif

#if defined(mips)
#define MIPS
#endif

#if defined(__alpha__)
#define ALPHA
#endif

#ifdef SPARC
#define HOST_ALIGN 4
#define QM_BIG_ENDIAN
#endif

#ifdef sgi
#define HOST_ALIGN 4
#define QM_BIG_ENDIAN
#endif

#if defined(HPPA) 
#define QM_BIG_ENDIAN
#define HOST_ALIGN 4
#endif

#if defined(m68k) || defined(m68000) || defined(_m68k_) || defined(mc68000)
#define QM_BIG_ENDIAN
#define HOST_ALIGN 2
#endif

#if !defined(HPPA) && defined(hpux)
/* good guess it is a 680x0 */
#define QM_BIG_ENDIAN
#define HOST_ALIGN 2
#endif


#ifdef QM_BIG_ENDIAN

#define WW(_addr_,_val_) (*(uw16*)(_addr_)=(_val_))
#define RW(_addr_) (*(uw16*)(_addr_))
#if (HOST_ALIGN>2)
static inline void _wl_(w32 *addr,w32 d)
{
  /*#if (HOST_ALIGN>2)*/
  if ((long)addr&2)
    {
      *(uw16*)addr=d>>16;
      *(((uw16*)addr)+1)=d&0xffff;
    }
  else
    /*#endif*/
    *addr=d;
}
static inline uw32 _rl_(w32 *addr)
{
  /*#if (HOST_ALIGN>2)*/
  if ((long)addr&2)
    return (w32) (((*(uw16*)addr)<<16)|((*(uw16*)(2+(long)(addr)))));
  else
    /*#endif*/
    return *addr;
}
#else /* HOST_ALIGN <=2 */
#define WL(_addr_,_val_) (*(uw32*)(_addr_)=(_val_))
#define RL(_addr_) (*(uw32*)(_addr_))
#endif

#else /* little endian stuff */

#if defined(__i486__) && defined(__GNUC__)

static inline uw16 _rw_(uw16 *s)
{	register uw16 x=*s;
	asm ( "rolw $8,%0\n" : "=c" (x) : "c" (x));
	return x;
}
static inline uw32 _rl_(uw32 *s)
{	register uw32 y=*s,x;
	asm ( "bswap %0\n" : "=S" (x) : "S" (y));
	return x;
}
static inline void _ww_(uw16 *d, uw16 v)
{	asm ( 	"xchgb %%ch,%%cl\n\t"
		"movw %%cx,(%%esi)\n"   
        : 
        : "c" (v), "S" (d)
        : "cx");
}
static inline void _wl_(uw32 *d, uw32 v)
{	asm (	"bswap %0\t\n"
		"movl %0,(%1)\n"   
        : 
        : "S" (v), "D" (d)
        );
}


#else /* i486 */

static inline uw16 _rw_(uw16 *s)
{
#if SWAP_LOAD_IN_MEMORY
	uw16* x = *(s);
	return ((x&0xff)<<8)|((x>>8)&0xff);
#else
	w8 *ss = (w8 *)s;
	uw8 *su = (uw8 *)s;
	return ((*(ss))<<8)|(*(su+1));
#endif
}
static inline uw32 _rl_(uw32 *s)
{
#if SWAP_LOAD_IN_MEMORY
	uw32 x = *(s);
	return ((x&0xff)<<24)|((x&0xff00)<<8)|((x>>8)&0xff00)|((x>>24)&0xff);
#else
	w8 *ss = (w8 *)s;
	uw8 *su = (uw8 *)s;
	return ((*(ss))<<24)|((*(su+1))<<16)
			|((*(su+2))<<8)|((*(su+3)));
#endif
}

static inline void _ww_(uw16 *d, uw16 v)
{
#if SWAP_STORE_IN_MEMORY
	*d=((v&0xff)<<8)|((v>>8)&0xff);
#else
	w8 *ds = (w8 *)d;
	uw8 *du = (uw8 *)d;
	*ds=v>>8;
	*(du+1)=v&0xff;
#endif
}

static inline void _wl_(uw32 *d, uw32 v)
{
#if SWAP_STORE_IN_MEMORY
	*d=((v&0xff)<<24)|((v&0xff00)<<8)|((v>>8)&0xff00)|((v>>24)&0xff);
#else
	w8 *ds = (w8 *)d;
	uw8 *du = (uw8 *)d;
	*ds= v>>24;
	*(du+1)=(v>>16)&0xff;
	*(du+2)=(v>>8)&0xff;
	*(du+3)=v&0xff;
#endif
}

#endif 

#ifndef RW
#define RW(_r_a)         _rw_((void *)(_r_a))
#endif
#ifndef RL
#define RL(_r_al)        _rl_((void *)(_r_al))
#endif
#ifndef WW
#define WW(_r_a,_r_v)    _ww_((void *)(_r_a), (_r_v))
#endif
#ifndef WL
#define WL(_r_al,_r_vl)  _wl_((void *)(_r_al),(_r_vl))
#endif

#endif

/*--------------------------------*/
/* here begins the actual program */

int fd;

unsigned long warncnt[4]={0,0,0,0};
char header[512];
unsigned long total_clusters,free_clusters,map_len,sectpc;
unsigned short *map=0;
unsigned long total_files=0;
unsigned long total_dirs=0;
unsigned long real_free_clusters=0;
unsigned long allocated_clusters=0;

typedef struct {
  unsigned short acnt;  /* how many files allocated this block.. hopefully only 1*/
  unsigned short me;    /* first map entry for this file */
  unsigned long de_pos; /* direntry pos of 1. file found that uses this buffer */
} mapentry;

mapentry *supp_map;


/* file header (directory entry) defs */

#define _flen 0
#define _facc 4
#define _ftyp 5
#define _finf1 6
#define _finf2 10
#define _fname 14
#define _fdupdt (0x34)
#define _fdtbak (0x3c)
#define _fdvers  0x38

#define SET_FLEN(_fh_,_len_) (WL((Ptr)_fh_,_len_))
#define GET_FLEN(_fh_)   (RL((Ptr)_fh_))
#define SET_FACC(_fh_,_len_) (WB((Ptr)_fh_+_facc,_len_))
#define GET_FACC(_fh_)   (RB((Ptr)_fh_+_facc))
#define SET_FTYP(_fh_,_len_) (WB((Ptr)_fh_+_ftyp,_len_))
#define GET_FTYP(_fh_)   ((unsigned char)*((Ptr)_fh_+_ftyp))
#define REF_FNAME(_fh_) ((char *)((char *)(_fh_)+_fname))
#define SET_FDUPDT(_fh_,_tme_) (WL((Ptr)_fh_+_fdupdt,_tme_))
#define SET_FDTBAC(_fh_,_tme_) (WL((Ptr)_fh_+_fdtbak,_tme_))

#define GET_FDUPDT(_fh_) (RL((Ptr)_fh_+_fdupdt))
#define GET_FDTBAC(_fh_) (RL((Ptr)_fh_+_fdtbak))


/* fs header defs */

#define QWA_ID(_p) ((uw32)RL((char*)(_p)+0x0))

#define QWA_IL(_p) ((uw16)RW((char*)(_p)+0x20))   /* interleave */

#define QWA_SPC(_p) ((uw16)RW((char*)(_p)+0x22))  /* sect per cluster(group)*/

#define QWA_SPT(_p) ((uw16)RW((char*)(_p)+0x24))  /* sect/track */
#define QWA_TPC(_p) ((uw16)RW((char*)(_p)+0x26))  /* track/cyl */
#define QWA_CPD(_p) ((uw16)RW((char*)(_p)+0x28))  /* ????????!!?? */
/* ignore sect_per_track*/
#define QWA_CC(_p) ((uw16)RW((char*)(_p)+0x2a))   /*#of groups(clusters)*/
#define QWA_FC(_p) ((uw16)RW((char*)(_p)+0x2c))   /* ..free.. */
#define QWA_SETFC(_p,_gn)   (WW((char*)(_p)+0x2c,(_gn)))

#define QWA_SPM(_p)  ((uw16)RW((char*)(_p)+0x2e)) /* length of map in 512 sector units */
#define QWA_MC(_p) ((uw16)RW((char*)(_p)+0x30))   /* # of maps */

#define QWA_FFC(_p)  ((uw16)RW((char*)(_p)+0x32))  /* linked list of free cls*/
#define QWA_SETFFC(_p,_gn)   (WW((char*)(_p)+0x32,(_gn)))
#define QWA_ROOT(_p) ((uw16)RW((char*)(_p)+0x34))  /*1.cluster# of root dir*/
#define QWA_RLEN(_p) ((uw32)RL((char*)(_p)+0x36))  /* root dir len in bytes*/
#define QWA_SETRLEN(_p,_gn)   (WL((char*)(_p)+0x36,(_gn))) 
#define QWA_FAT(_p)  (((char*)(_p)+0x40))          /* beginning of map (fat) */

#define QWDE_FNUM(_p) ((uw16)RW((Ptr)(_p)+0x3a))
#define QWDE_SETFNUM(_p,_gn)   (WW((char*)(_p)+0x3a,(_gn)))

static char *filename;
static int verbose=8;

#define V2 (verbose>=2)
#define V4 (verbose>=4)
#define V6 (verbose>=6)
#define V8 (verbose>=8)
#define V10 (verbose>=10)

#ifdef __QDOS__
char _prog_name[]="qxl_fschk";
#endif

int do_exit(int code)
{
  code |= 2*(warncnt[0]>0) | 4*(warncnt[1]>0) | 8*(warncnt[2]>0);
  exit(code);
}

void errexit(char *msg, int code){if(verbose)printf("FATAL: %s\n",msg);do_exit(code);}
void perrexit(char *msg, int code){if(verbose){perror("FATAL ");printf("..while %s\n",msg);}do_exit(code);}
void warn(char *msg, int cnt){if(V4)printf("WARNING: %s\n",msg);warncnt[cnt]+=cnt;}

void check_header()
{
  unsigned long x;

  if (QWA_ID(header)!=((('Q'*256+'L')*256+'W')*256+'A'))
    errexit("no QLWA id in header",8);
  if (QWA_IL(header)) errexit("can't handle interleave",8);
  if (QWA_MC(header)>1) errexit("can't handle #maps>1",4);
  if (QWA_MC(header)==0) warn("strange filesystem..zero maps?!?",2);
  total_clusters=QWA_CC(header);
  free_clusters=QWA_FC(header);
  map_len=QWA_SPM(header);
  x=(total_clusters*2+511+0x40)/512;
  if (x!=map_len)
    {
      if (x<map_len && (map_len-x)<3)
	{
	  warn("map len doesn't match expected value",1);
	}
      else
	{
	  if ( x-map_len<1)
	    { 
	      warn("QWA_SPM should be fixed",1);
	      if(V6)printf("current value %ld expected value %ld\n",map_len,x);
	    }
	  else errexit("QWA_SPM wrong value",4);
	}
    }
  sectpc=QWA_SPC(header);
  if (QWA_RLEN(header)<64 || (QWA_RLEN(header)%64))
    errexit("root directory bad length",8);
}

void load_map()
{
  unsigned long i;

  if(lseek(fd,0,SEEK_SET) <0)
    perrexit("loading map",1);
  map=malloc(map_len*512);
  if (!map) errexit("memory allocation failed",1);
  supp_map=malloc(map_len*256*sizeof(mapentry));
  if (!supp_map) errexit("memory allocation failed",1);
  if ( map_len*512 != read(fd,map,map_len*512))
    perrexit("failed loading map",1);
  map = (short*)((char*)map+0x40);
  for(i=0; i<map_len*256-0x20; i++)
    {
      map[i]=RW(&(map[i]));
      supp_map[i].acnt=0;
      supp_map[i].me=0;
      supp_map[i].de_pos=0;
    }
}

/* shared by next 2 functions */
static char dentry[64];

/*de_pos=0 is ROOT_DIR, =1 is MAP, =2 is FREE_LIST*/
char *getfname(unsigned long de_pos)
{
  static char name[64];
  static char buf[512];
  char *p=(char *)buf+(de_pos%512);
  unsigned long ipos=(de_pos/512)*512;

  if (de_pos<3)
    switch(de_pos)
      {

      case 0: strcpy(name,"# Root Direcory #"); return name;
      case 1: strcpy(name,"# File System Map #"); return name;
      case 2: strcpy(name,"# Free Cluster List #"); return name;
      }

  if(lseek(fd,ipos,SEEK_SET) <0)
    perrexit("loading directory entry",1);
  if (512>read(fd,buf,512))
    perrexit("failed loading directory entry",1);
  memcpy(dentry,p,64);

  ipos=RW(REF_FNAME(p));
  strncpy(name,REF_FNAME(p)+2,64);
  name[ipos]=0;
  return name;
}
void pentry(char *entry)
{
  int nlen,i;
  
  nlen=RW(REF_FNAME(entry));
  if (nlen>36)
    printf("name longer 36\n"),nlen=36;
  if (nlen)
    for (i=0;i<nlen;i++)
      {
	printf("%c",*(REF_FNAME(entry)+2+i));
      }
  else printf("ZERO NAME");
}
void pfname(unsigned long de_pos)
{
   if (de_pos<3)
    switch(de_pos)
      {

      case 0: printf("# Root Direcory #"); return ;
      case 1: printf("# File System Map #"); return ;
      case 2: printf("# Free Cluster List #"); return ;
      } 
  getfname(de_pos);
  pentry(dentry);
}
/* return +ve when circularity detected */
int  mark_map(unsigned long nm,unsigned long me,unsigned long de_pos)
{
  int xwarn=0;
  int retval=0;

  if (!supp_map[nm].acnt)
    {
      supp_map[nm].acnt=1;
      supp_map[nm].me=me;
      supp_map[nm].de_pos=de_pos;
    }
  else
    {
      supp_map[nm].acnt+=1;
      if (supp_map[nm].me==me && supp_map[nm].de_pos==de_pos)
	{
	  warn("circularity in buffer allocation detected",2);
	  retval=1;
	  if (V6)
	    {
	      printf("cluster %ld  allocated by file with de_pos=%ld, me=%d\n",
		     nm,supp_map[nm].de_pos,supp_map[nm].me);
	      printf(" file ");
	      pfname(de_pos);printf("\n");
	      xwarn++;
	    }
	}
      if((V4 && xwarn==0) || V6)
	{
	  printf("cluster %ld allocated %d times, 1st allocation by file de_pos=%ld",
		 nm,supp_map[nm].acnt,supp_map[nm].de_pos);
	  pfname(supp_map[nm].de_pos);
	  printf(" now allocated de_pos=%ld\n",de_pos);
	  pfname(de_pos);printf("\n");
	  xwarn++;
	}
      warncnt[2]++;
    }
  return retval;
}

int check_mapentry(unsigned long me, unsigned long *count, unsigned long de_pos)
{
  unsigned long nm,i;
  if (me>=total_clusters )
    {
      if(V4)printf("map entry points beyond cluster list; %s, de_pos=%ld\n",getfname(de_pos),de_pos);
      return 1;
    }
  /* de_pos 1 IS system map */
  if (me < ((total_clusters+0x20)*2/(512*sectpc)) && (de_pos !=1))
    {
      warn("mapentry points into map of map ?!?",2);
      if(V4)
	{
	  printf("; %s, de_pos=%ld\n",getfname(de_pos),de_pos);
	  printf("...mapentry: %ld\n",me);
	}
    }
  if (mark_map(me,me,de_pos)) return 1;
  i=1;nm=map[me];
  while(nm)
    {
      if (mark_map(nm,me,de_pos)) return 1;
      nm=map[nm]; i++;
      if ( i>=total_clusters )
	{
	  if(V4)printf("error for file %s with mapentry %ld, de_pos=%ld\n",getfname(de_pos),me,de_pos);
	  warn("circularity in map list ?!?",2);
	  break;
	}
      if ( nm>=total_clusters )
	{
	  if(V4)printf("error for file %s with mapentry %ld, de_pos=%ld\n",getfname(de_pos),me,de_pos);
	  warn("nonexisting cluster allocated",2);
	  break;
	}
    }
  *count=i;
  return 0;
}
void check_dir(unsigned long me, unsigned long de_pos, unsigned long len,unsigned long indent)
{
  char *ccluster,*p;
  unsigned long ilen=0;
  unsigned long l,lde_pos,nm,lnm;
  
  total_dirs++;

  if (V8)
    {
      printf("checking dir: ");
      for (l=0;l<indent;l++)printf(" ");
      pfname(de_pos);printf("\n");
    }

  if (len%64)
    {
      if(V4)printf("malformed directory %s, de_pos=%ld - length not |64\n",getfname(de_pos),de_pos);
      warncnt[2]++;
    }

  ccluster=malloc(512*sectpc);
  if (!ccluster) errexit("memory allocation failed",1);

  lnm=nm=me;ilen=0x40;
  for(;ilen<len; ilen+=0x40)
    {
      if ((ilen%(512*sectpc))==0 || ilen==0x40)
	{
	  if(lseek(fd,nm*512*sectpc,SEEK_SET) <0)
	    perrexit("loading cluster",1);
	  if ( 512*sectpc != read(fd,ccluster,512*sectpc))
	    perrexit("failed loading map",1);
	  lnm=nm;
	  nm=map[nm];
	}
      p=ccluster+(ilen%(512*sectpc));
      if (GET_FLEN(p)>=0x40) /* valid entry ?*/
	{
	  total_files++;
	  lde_pos=(ilen%(512*sectpc))+lnm*512*sectpc;
	  if(verbose>=10)
	  {
	    printf("checking file: ");
	    for (l=0;l<indent;l++)printf(" ");
	    /*pfname(lde_pos);*/
	    pentry(p);
	    printf(" de_pos=%ld, me=%d...\n",lde_pos,QWDE_FNUM(p));
	  }
	  l=RW(REF_FNAME(p));
	  if(l==0 || l>36)
	    {
	      if(V4)printf("bad name:len %ld, %s, de_pos=%ld\n",l,REF_FNAME(p)+2,lde_pos);
	      warn("bad name",2);
	    }
	  if (check_mapentry(QWDE_FNUM(p),&l,lde_pos))
	    continue; /* file is garbage :-( */
	  if (GET_FLEN(p) > l*512*sectpc)
	    {
	      if(V4)printf("length specified in directory entry exceeds allocated\n"
		     "cluster space: %s de_pos=%ld\n",REF_FNAME(p)+2,lde_pos);
	      warncnt[2]++;
	    }
	  if (GET_FLEN(p) < (l-1)*512*sectpc)
	    {
	      if(V4)printf("hm, looks like more clusters are allocated than needed\n"
		     "for file %s de_pos=%ld, length=%d clusters=%ld\n",REF_FNAME(p)+2,lde_pos,GET_FLEN(p),l);
	      warncnt[1]++;
	    }
	    if (GET_FTYP(p) == 255)
	      {
		total_files--; /* correct for statistics */
	      	check_dir(QWDE_FNUM(p),lde_pos,GET_FLEN(p),indent+3);
         	}
#if 0
	    else
	      {
		printf("checked file: ");
		for (l=0;l<indent;l++)printf(" ");
		pentry(p);printf("\n");
	      }
#endif
	}
    }
  free(ccluster);
}

void usage(char *msg, char **av)
{
  printf("%s\n"
	 "usage: %s [-v lev] image_name",
	 msg, av[0] );
}

void get_args(int ac, char **av)
{
  int i;
  char *p;

  if (ac<2)
    {
      if(verbose)usage("QXL.WIN filename expected\n",av);
      exit(1);
    }
  for(i=1; i<ac; i++)
    switch (av[i][0])
      {
      case '-':
	if (av[i][2]) p=&av[i][2]; 
	else p=av[++i];
	if (!isdigit(*p))
	  printf("wrong arg for '-v'\n");
	verbose=atoi(p);
	break;
      default: filename=av[i]; return;
      }
}


int main (int ac, char **av)
{
  int ec;
  unsigned long c;

  get_args(ac,av);

  fd=open(filename,O_RDONLY);
  if (fd<0)
    perrexit("could not open file/partition",1);
  

  ec=read(fd,header,512);
  if (ec<512)
    perrexit("could not read header",1);

  check_header();
  if (V8) printf("sectors per cluster %ld\n",sectpc);
  load_map();
  if (check_mapentry(QWA_ROOT(header), &c,0))
    errexit("root directory in wrong place",8);
  if ((QWA_RLEN(header)+sectpc*512-1)/(512*sectpc) > c)
    warn("root dir len exceeds cluster count",1);
  if ((QWA_RLEN(header)+sectpc*512-1)/(512*sectpc) != c)
    warn("root dir len doesn't match cluster count",1);
  check_mapentry(0,&c,1);
  if(c*sectpc > QWA_SPM(header)*512 )
    warn("map entry for map too long or malformed",4);
  check_dir(QWA_ROOT(header),0,QWA_RLEN(header),0);
  if (V8)
    printf("\n..done file scanning, now looking at statistics\n");
  for(c=0;c<QWA_CC(header);c++)
    if(supp_map[c].acnt) allocated_clusters++;
  if (free_clusters>0)
    check_mapentry(QWA_FFC(header),&c,2);
  for(c=0;c<QWA_CC(header);c++)
    if(supp_map[c].acnt) real_free_clusters++;
  real_free_clusters -= allocated_clusters;
  if (allocated_clusters+real_free_clusters<QWA_CC(header))
    warn("lost clusters",1);

  if(verbose)printf("check completed,  %ld less severe, %ld serious, %ld very serious warnings\n",warncnt[0],warncnt[1],warncnt[2]);
  if(verbose)printf("allocated clusters %ld, real free cluster %ld\n",allocated_clusters,real_free_clusters);
  if(verbose)printf("checked %ld direcories %ld files\n",total_dirs,total_files);
  if (allocated_clusters+real_free_clusters<QWA_CC(header))
    {
      if(verbose)printf("looks like %ld clusters are lost\n",QWA_CC(header)-allocated_clusters-real_free_clusters);
      if(V10 || (verbose && QWA_CC(header)-allocated_clusters-real_free_clusters < 1024) )
	{
	  printf("printing lost clusters: \n");
	  for(c=0; c<QWA_CC(header); c++)
	    if(!supp_map[c].acnt) printf("%ld ",c);
	}
    }
  return do_exit(0);
}
